This empty directory is where this python script stores the files that it creates. 
It is best to keep this empty, so as not to clutter it with older unrelated files.